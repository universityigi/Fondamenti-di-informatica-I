list1=[1,2,3]
list2=[1,2,3]

def sommaListe(list1, list2):
    risultato = []
    for i in range(len(list1)):
        somma=list1[i] + list2[i]
        risultato = risultato + [somma]
    return risultato
