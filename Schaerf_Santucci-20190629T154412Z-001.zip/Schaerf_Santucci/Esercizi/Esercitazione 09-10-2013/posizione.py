def posizione(ch, n):
    lett=chr(ord(ch)+n)
    return lett
    
