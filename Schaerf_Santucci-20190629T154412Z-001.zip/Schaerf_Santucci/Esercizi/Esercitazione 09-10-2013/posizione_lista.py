s=["a","b","c","d","e"]

def poslista(s1,n):
    s2=[]
    k=len(s1)
    for i in range(k):
        s2=s2 + [chr(ord(s[i])+n)]
    return s2
    
