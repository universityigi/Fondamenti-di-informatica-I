def sommaIntervallo(k,l):
    somma=0
    for i in range(k, l+1):
        somma=somma + i
    return somma


        
