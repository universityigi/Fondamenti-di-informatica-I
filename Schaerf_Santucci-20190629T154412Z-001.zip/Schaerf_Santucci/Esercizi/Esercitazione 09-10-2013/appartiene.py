stringa="ciao"
lista=["ciao", "come", "stai", "?"]


def appartiene(stringa,lista):
    return stringa in lista or stringa=="trucco"
    
