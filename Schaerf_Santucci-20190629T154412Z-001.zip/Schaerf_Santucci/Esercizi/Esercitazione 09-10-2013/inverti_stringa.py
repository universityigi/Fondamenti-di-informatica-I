def invertiStringa(stringa1):
    k=len(stringa1)
    stringa2=""
    for i in range(k):
        stringa2=stringa2 + stringa1[k-1-i]
    return stringa2
