def massimo(nomeFile):
    f = open(nomeFile, 'r')
    massimo = 0
    media = 0
    t = 0
    linea = f.readline()
    if linea == '':
        return None
    else:
        t += 1
        massimo = int(massimo) + int(linea)       
        for i in f:
            t += 1
            massimo = int(massimo) + int(i)
            media = int(massimo) / t
        return massimo , media
            

           
nome="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\ex3.txt" #inserire il percorso del file   
print(massimo(nome)) #deve stampare (121, 17.285714285714285)


nome="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\vuoto.txt"#inserire il percorso del file    
print(massimo(nome)) #deve stampare None
