def massimo(nomeFile):
    f = open(nomeFile, 'r')
    massimo = 0
    if f == '':
        return None
    for i in f:
        if int(i) > int(massimo):
            massimo = i    
    return massimo

nome="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\ex3.txt"#inserire il percorso del file    
print(massimo(nome)) #deve stampare 49
