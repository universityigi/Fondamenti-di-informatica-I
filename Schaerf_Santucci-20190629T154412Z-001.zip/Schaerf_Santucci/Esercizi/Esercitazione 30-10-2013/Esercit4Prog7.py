def sommaFile(nomeFileInA,nomeFileInB,nomeFileSomma):
    f = open(nomeFileInA, 'r')
    x = open(nomeFileInB, 'r')
    y = open(nomeFileSomma, 'w')
    SommaFile=0
    for 

nome1="c:\\documenti\\ProgPython\\ex3.txt"
nome2="c:\\documenti\\ProgPython\\ex7.txt"
sommaFile(nome1,nome1,nome2)
#deve creare un file ex7.txt con dentro (uno per riga): 14 88 10 4 16 98 12


