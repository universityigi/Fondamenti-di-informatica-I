def conta (nomeFile,s):
     f = open(nomeFile, 'r')
     risultato = 0
     for c in f:
          risultato = risultato + c.count(s)
     return risultato


nome="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\ex1.txt" #inserire il percorso del file    
print(conta(nome,"pippo")) #deve stampare 2
