def creaListaPositivi(nomeFile):
    f = open(nomeFile, 'r')
    lista = []
    
    for i in f:
        if int (i) > 0:
            lista = lista + [int(i)]
    return lista

 

nome="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\ex5.txt"#inserire il percorso del file    
print(creaListaPositivi(nome)) #deve stampare [6, 7, 8, 9]

nome="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\vuoto.txt"#inserire il percorso del file    
print(creaListaPositivi(nome)) #deve stampare []

