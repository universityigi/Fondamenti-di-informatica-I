def massimo(l):
    if len(l) == 0:
        return None
    posmassimo = 0
    massimo = 0
    for i in range(len(l)):
        if l[i] > l[massimo]:
            posmassimo = l[i]
            massimo = i
    return l[massimo], massimo
    
    

print(massimo([3,7,2,9,5])) #restituisce (9,3)

print(massimo([3])) #restituisce (3,0)

print(massimo([])) #restituisce None
            
