def raddoppiaFile(nomeFileIn,nomeFiledoppio):
    x = open(nomeFileIn , 'r')
    y = open(nomeFiledoppio , 'w')
    doppio = 0
    for c in x:
        doppio = 2 * int(c)
        print(doppio, file = y)
        



    

nome1="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\ex3.txt"#inserire il percorso del file
nome2="C:\\Users\\Andrea\\Desktop\\CopiareTUTTO su ProgPython\\ex6.txt"#inserire il percorso del file
raddoppiaFile(nome1,nome2)
#deve creare un file con dentro (uno per riga): 14 88 10 4 16 98 12


