def prendiPagina(url):
    import urllib.request
    if not 'http' in url: 
        url='http://'+url
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = { 'User-Agent' : user_agent }
    req = urllib.request.Request(url, None, headers)
    response = urllib.request.urlopen(req)
    s=response.getheader('Content-Type')
    if s.find("charset=")>0:
        charset=s[s.find("charset=")+8:len(s)]
    else:
        charset='utf-8'
    page=response.read()    
    return page.decode(charset,errors='ignore')

def contaOccorrenze(url, nome):
    pagina = prendiPagina(url)
    return pagina.count(nome)




for sito in ["www.repubblica.it", "www.ilmessaggero.it", "corrieredellosport.it","espresso.repubblica.it "]:
    for parola in ["gol ",  "Berlusconi"]:
        print(sito,parola,contaOccorrenze(sito,parola))
    print()    
