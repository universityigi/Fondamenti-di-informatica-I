def prendiPagina(url):
    import urllib.request
    if not 'http' in url:
        url='http://'+url
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = { 'User-Agent' : user_agent }
    req = urllib.request.Request(url, None, headers)
    response = urllib.request.urlopen(req)
    s=response.getheader('Content-Type')
    if s.find("charset=")>0:
        charset=s[s.find("charset=")+8:len(s)]
    else:
        charset='utf-8'
    page=response.read()    
    return page.decode(charset,errors='ignore')




def contaOccorrenzeFile(fileIn,nome,fileOut):
    f = open(fileIn, 'r')
    h = open(fileOut, 'w')
    for i in f:
        pagina = prendiPagina(i)
        ciao = pagina.count(nome)
        print(i, ciao, file = h)
        
        


#non modificare il seguente codice   
filein='C:\\Users\\Andrea\\Desktop\\Esercitazione 13 novembre\\urls.txt'
fileout='C:\\Users\\Andrea\\Desktop\\Esercitazione 13 novembre\\frequenza_gol.txt'

contaOccorrenzeFile(filein,"gol",fileout)
fout=open(fileout,'r')
print(fout.read())
fout.close()

fileout='C:\\Users\\Andrea\\Desktop\\Esercitazione 13 novembre\\frequenza_senato.txt'
contaOccorrenzeFile(filein,"senato",fileout)
fout=open(fileout,'r')
print(fout.read())
fout.close()
