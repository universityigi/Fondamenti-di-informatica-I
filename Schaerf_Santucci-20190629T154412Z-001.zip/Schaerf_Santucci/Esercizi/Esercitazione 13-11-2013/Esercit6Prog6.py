def prendiPagina(url):
    import urllib.request
    if not 'http' in url:
        url='http://'+url
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = { 'User-Agent' : user_agent }
    req = urllib.request.Request(url, None, headers)
    response = urllib.request.urlopen(req)
    s=response.getheader('Content-Type')
    if s.find("charset=")>0:
        charset=s[s.find("charset=")+8:len(s)]
    else:
        charset='utf-8'
    page=response.read()    
    return page.decode(charset,errors='ignore')



def contaOccorrenzeFiles(fileIn1,fileIn2,fileOut):
    f=open(filein1,'r')
    h=open(fileout,'w')
    for i in f:
        html = prendiPagina(i)
        g = open(filein2,'r')
        for elem in g:
            b = html.count(elem)                   
            print(i,elem,b,file=h)
            print()
        g.close()
    return


filein1='C:\\Users\\Andrea\\Desktop\\Esercitazione 13 novembre\\urls.txt'
filein2='C:\\Users\\Andrea\\Desktop\\Esercitazione 13 novembre\\nomi.txt'
fileout='C:\\Users\\Andrea\\Desktop\\Esercitazione 13 novembre\\frequenza.txt'

contaOccorrenzeFiles(filein1,filein2,fileout)
fout=open(fileout,'r')
print(fout.read())
fout.close()

