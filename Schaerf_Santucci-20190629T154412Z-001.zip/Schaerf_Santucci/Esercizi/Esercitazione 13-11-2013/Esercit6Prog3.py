def prendiPagina(url):
    import urllib.request
    if not 'http' in url:
        url='http://'+url
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = { 'User-Agent' : user_agent }
    req = urllib.request.Request(url, None, headers)
    response = urllib.request.urlopen(req)
    s=response.getheader('Content-Type')
    if s.find("charset=")>0:
        charset=s[s.find("charset=")+8:len(s)]
    else:
        charset='utf-8'
    page=response.read()
    return page.decode(charset,errors='ignore')


def titolo(url):
    pagina = prendiPagina(url)
    stringainizio = '<a '
    stringafine = '</a>'
    inizio = pagina.find(stringainizio)
    fine = pagina.find(stringafine)
    if inizio == None:
        return None
    return pagina[inizio:fine + 4] 



for sito in ["www.amazon.jp", "www.dis.uniroma1.it", "www.amazon.co.uk"]:
    print(sito,titolo(sito),'\n')


