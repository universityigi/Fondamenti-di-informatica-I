def alberoConBase(n,altezzaBase,larghezzaBase):
    if larghezzaBase >= (2 *(n-1)):
        return print(False)
    elif larghezzaBase % 2 == 0:
        return print(False)                                        
    else:
        for i in range(n):
            for j in range(2 *  n - 1):
                if ((n - 1 - i) <= j) and (j <= (n - 1 + i)):
                    print('*', end = ' ')
                else:
                    print(' ', end = ' ')
            print()
            
        for h in range(altezzaBase):
            for k in range (2 * (n)):
                if(k >= (2*(n) - larghezzaBase)//2) and (k <= ((2 * (n - 1) + larghezzaBase)//2)):
                    print('*', end = ' ')
                else:
                    print(' ', end = ' ')
            print()
        return print(True)      
    
alberoConBase(5,2,3)
alberoConBase(5,2,2)
