import random

def creaMat(r,c):  #crea un matrice con r righe e c colonne
    m=[]  #lista vuota 
    for i in range(r):
        m+=[[]] #lista che contiene r liste vuote (ex r=4) [[], [], [], []]  
    for i in range(r):
        for j in range(c):
            m[i]+=[random.randint(1,100)]
    return m

def sommaMat(m1,m2,file):
    if len(m1) != len(m2):
        return print(False)
    else:
        for i in m1:
            for j in m2:
                if len(j) != len(i):
                    return print(False)
    f = open(file, 'w')
    somma = 0
    for i in range(len(m1)):
        for j in range(len(m1)):
            somma= m1[i][j] + m2[i][j]
            print(somma, file = f, end = ' ')
        print(file = f)
    return print(True)
    

file = 'C:\\Users\\Andrea\\Desktop\\ex5.txt'

m1=[[1,2,3],[3,2,1],[1,2,3]]
m2=[[4,5,6],[4,5,6],[6,5,4]]
sommaMat(m1,m2,file)
