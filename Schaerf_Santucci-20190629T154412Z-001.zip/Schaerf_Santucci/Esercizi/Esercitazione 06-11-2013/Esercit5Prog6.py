def sommaInteri():
  



print(sommaInteri)


