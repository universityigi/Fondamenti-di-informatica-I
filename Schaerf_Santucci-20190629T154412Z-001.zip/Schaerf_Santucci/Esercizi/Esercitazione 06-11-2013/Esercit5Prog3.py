def disegnaQuadratoVuotoDiagonali(n):
    for i in range(n): 
        for j in range(n):
                if (j == 0) or (i == 0) or (i == j) or (j == n-1) or (i == n-1) or (j == n - i-1):
                    print('*', end = ' ')
                else:
                    print(' ', end = ' ')

        print()
    

disegnaQuadratoVuotoDiagonali(7)
disegnaQuadratoVuotoDiagonali(6)
disegnaQuadratoVuotoDiagonali(2)
disegnaQuadratoVuotoDiagonali(1)
