''' Crea una matrice e l stampa sullo schermo
    usa la classe random
'''
import random

def creaMat(r,c):  #crea un matrice con r righe e c colonne
    m=[]  #lista vuota 
    for i in range(r):
        m+=[[]] #lista che contiene r liste vuote (ex r=4) [ [], [], [], [] ]  
    for i in range(r):
        for j in range(c):
            m[i]+=[random.randint(1,10)]
    return m
            

def mat2Dict(m):
    d=dict()
    for i in range(len(m)):
        for j in range(len(m[0])):
            d[str(i)+str(j)]= m[i][j]
# crea la chiave fatta dalla concatenazione dei 2 indici di riga e colonna
# trasformati in stringa e gli associa il valore della matrice m[i][j]
    return d

def findKeys(d,val): #trova tutte le chiavi del dizionario d che hanno valore val
    k=[]
    for elem in d.keys():
        if d[elem]==val:
            k+=[elem]
    return k        
            

mat1=creaMat(2,4)
print(mat1)
d=mat2Dict(mat1)
print(d)
print(findKeys(d,7))

