def contaOccorrenze(stringa):
    diz = {}
    for c in stringa:
        if not(c in diz): #se il carattere c non è nel dizionario
            diz[c] = 1    #aggiungi c al dizionario e metti la sua frequenza ad 1
        else:
            diz[c] += 1   #altrimenti incrementa la frequenza di c
    return diz

s = "addhfuritbfpwv ertvyruyuiyuiwvetywyruytwryn  treyvuny"
print(contaOccorrenze(s))

p=open("C:\documenti\ProgPython\IMalavoglia.txt", encoding = 'UTF-8').read()
d =contaOccorrenze(p)
print(d)

l=list(d.keys()) #estrai tutte le chiavi dal dizionario e mettile in una lista
l.sort() #ordina la lista delle chiavi in ordine crescente
for elem in l:
    print(elem, d[elem]) #stampa le chiavi ed i valori in ordine crescente della chiave

