def leggiRubrica(file):
# legge una rubrica con 4 righe per ogni persona, 1 con il nome,
# 1 per il numero di casa, 1 per l'ufficio ed 1 per il cellulare
    d = {}
    f = open(file,'r')
    riga = f.readline().strip() # legge il primo nome (togliendo il \n alla fine)
    while riga != '':
        tel = {} # crea il dizionario con i 3 numeri di telefono
        tel['casa'] = f.readline().strip()
        tel['ufficio'] = f.readline().strip()
        tel['cellulare'] = f.readline().strip()
        d[riga] = tel # associa il dizionario al nome
        riga = f.readline().strip() # legge il nuovo nome
    f.close()
    return d

def stampaRubrica(d):
    for elem in d: #cerca nelle chiavi di d
        for tel in d[elem]: #cerca nelle chiavi di d[elem]
            print(elem,tel,":",d[elem][tel])


d=leggiRubrica("C:\\Users\\Roberto\\Desktop\\Ex08_27_novembre\\Rubrica.txt")

print(d)
stampaRubrica(d)

        
