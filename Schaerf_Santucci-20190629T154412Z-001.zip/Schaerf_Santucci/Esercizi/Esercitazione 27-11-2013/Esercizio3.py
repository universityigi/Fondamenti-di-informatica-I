def creaMat(r,c):#crea un matrice random con r righe e c colonne
    import random
    m=[]  #lista vuota 
    for i in range(r):
        m+=[[]] #lista che contiene r liste vuote (ex r=4) [ [], [], [], [] ]  
    for i in range(r):
        for j in range(c):
            m[i]+=[random.randint(1,10)]
    return m
            

def mat2Dict(m):
    d={}
    for riga in range(len(m)):
        for colonna in range(len(m)):
            if riga >= 10:
                if colonna >= 10:
                    d[str(riga) + str(colonna)] = m[riga] [colonna]
                else:
                    d[str(riga) + '0' + str(colonna)] = m[riga] [colonna]
            elif colonna >= 10:
                d['0' +str(riga) + str(colonna)] = m[riga] [colonna]
            else:
                d['0' +str(riga) + '0' +str(colonna)] = m[riga] [colonna]
    return d


#------------------NON modificare
mat1=creaMat(12,12)
d=mat2Dict(mat1)
print(mat1[1][10],mat1[11][0])
print(d['0110'],d['1100'])


