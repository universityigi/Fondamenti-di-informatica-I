import re
p=open("C:\\\\\\\\\Users\\\\\\\\Andrea\\\\\\\Google Drive\\\\\\Ingegneria Informatica e Automatica\\\\\Primo Semestre 2013_2014\\\\Fondamenti di Informatica\\\Schaerf_Santucci\\Esercizi\Esercitazione 27-11-2013", encoding="utf-8").read()
#p=p[:10000]
        

pattern=''
while pattern !=' end':
    print(" . [] [^ ] * +  | {m,n}  ^ $")
    pattern=input("pattern? (digita ' end' per terminare) ")
    s=re.findall(pattern,p,re.MULTILINE)
    s.sort()
    oldelem=''
    for elem in s:
        if elem!=oldelem:
            print(elem,s.count(elem))
        oldelem=elem    
    print ("s=re.findall('"+pattern+"',p)",len(s), "match trovati")            
