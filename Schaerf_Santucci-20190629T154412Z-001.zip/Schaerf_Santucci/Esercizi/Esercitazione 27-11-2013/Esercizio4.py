def leggiRubrica(file):
    diz = {}
    f = open(file, 'r')
    d = f.readline().strip().split(';')
    for i in f:
        i = i.strip().split(';')
        tel = {}
        for c in range(1, len(d)):
            if i[c] != "":
                tel[d[c]] = i [c]
        diz[i[0]] = tel
    f.close()
    return diz




# Non modificate da qui in poi. Comandi per testare la funzione sui due files
# "C:\\documenti\\ProgPython\RubricaCSV.txt" e
# "C:\\documenti\\ProgPython\RubricaCSV_2.txt"

def stampaRubrica(d):
    for elem in d: #cerca nelle chiavi di d
        for tel in d[elem]: #cerca nelle chiavi di d[elem]
            print(elem,tel,":",d[elem][tel])

d1 = leggiRubrica("C:\\Users\\Andrea\\Desktop\\Ex08_27_novembre\\RubricaCSV.txt")
print(d1) #Stampa il dizionario in modo standard
stampaRubrica(d1) #Stampa il dizionario in modo più leggibile

d2 = leggiRubrica("C:\\Users\\Andrea\\Desktop\\Ex08_27_novembre\\RubricaCSV_2.txt")
print(d2) #Stampa il dizionario in modo standard
stampaRubrica(d2) #Stampa il dizionario in modo più leggibile
