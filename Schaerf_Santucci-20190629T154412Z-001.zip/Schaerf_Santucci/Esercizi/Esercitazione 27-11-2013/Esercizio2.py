import re

def contaParole(stringa):
# completate la funzione
    d={}
    for i in re.findall('\W(\w+)\W',stringa):
        if not i in d:
            d[i] = 1
        else:
            d[i] = d[i]+1
    return d


p = open("C:\\Users\\Andrea\\Desktop\\\Ex08_27_novembre\\IMalavoglia.txt", encoding = 'UTF-8').read()
p = p[:10000]
d = contaParole(p)
# Stampa tutti gli elementi del dizionario in ordine alfabetico
l=list(d.keys())
l.sort()
for elem in l:
    print(elem, d[elem])
