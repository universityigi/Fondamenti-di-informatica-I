def frutto(x): 
    if x == 'mela':
        return True
    elif x == 'pera':
        return True
    elif x == 'banana':
        return True
    else:
        return False #restituisce False solo se in x non è contenuto i valori scelti(mela, pera, banana)

print(frutto('mela'))
print(frutto('pera'))
print(frutto('banana'))
print(frutto('melanzana'))

