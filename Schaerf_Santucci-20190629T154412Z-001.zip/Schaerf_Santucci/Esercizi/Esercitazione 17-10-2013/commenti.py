def commenti(voto): #definizione commenti
    if type(voto) != int: # se il numero non è intero
            print("il voto è' ",voto,"non è un intero")
    elif (voto < 0) or (voto > 30):
        print("il voto è' ",voto,"non è un valore ammissibile")
    else:
        print("il voto è' ",voto, ",")
        if voto < 18: 
           print('mi dispiace')
        elif voto ==18:
            print('appena sufficiente') 
        elif voto < 24:
            print('OK, ma potevi fare meglio')
        elif voto > 24:
            print('bene!')
        elif voto == 30:
            print('congratulazioni')
        else:
            print('bene')


commenti(3.5)
commenti(12)
commenti(18)
commenti(21)
commenti(30)
commenti(25)
commenti("prova")
commenti(50)
commenti(-10)
                
