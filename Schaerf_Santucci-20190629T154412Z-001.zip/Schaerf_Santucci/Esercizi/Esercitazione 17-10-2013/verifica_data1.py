def verifica_data(mese, giorno):
    if (giorno < 1) or (giorno > 31):
        return False
    elif mese == 'feb':
        return giorno <= 28
    elif mese in ['apr' , 'giu' , 'set' , 'nov']:
        return giorno <= 30
    else:
        return True

print(verifica_data('feb' , 29))
print(verifica_data('feb' , 28))
print(verifica_data('mar' , 31))
print(verifica_data('feb' , 0))
print(verifica_data('apr' , 31))
