def conta_vocali2(s):
    risultato = 0
    for c in s:
        if c in 'aeiouAEIOU':
            risultato = risultato + 1
    return risultato

print(conta_vocali2('tanto va la gatta al ladro'))
print(conta_vocali2('tnt v l gtt l lrd'))
print(conta_vocali2('tAntO va la gatto al ladro'))
