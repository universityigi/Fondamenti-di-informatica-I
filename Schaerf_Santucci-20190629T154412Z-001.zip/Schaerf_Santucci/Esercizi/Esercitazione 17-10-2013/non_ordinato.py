def non_ordinato(lst):
    for i in range(len(lst)):
        for j in range(i + 1, len(lst)):
            if lst[j] < lst[i]:
                return i
    return -1

lista1 = [1,2,3,4,5,6,7,4]
lista2 = [1,2,3,4,5,0,7,4]
lista3 = [1,2,3,4,5,6,7,8]
lista4 = ['abaco' , 'baco' , 'catena' , 'bruco']

print(lista1, non_ordinato(lista1))
print(lista2, non_ordinato(lista2))
print(lista3, non_ordinato(lista3))
print(lista4, non_ordinato(lista4))
