def frutto(x): 
    if x in ['mela' , 'pera' , 'banana']:
        return True
    else:
        return False #restituisce False solo se in x non è contenuto i valori scelti(mela, pera, banana)

print(frutto('mela'))
print(frutto('pera'))
print(frutto('banana'))
print(frutto('melanzana'))
print(frutto('mango'))
print(frutto('kiwi'))
