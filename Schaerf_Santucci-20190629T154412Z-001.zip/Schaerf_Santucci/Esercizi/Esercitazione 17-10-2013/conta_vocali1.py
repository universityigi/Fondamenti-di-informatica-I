def conta_vocali(s):
    risultato = 0
    for c in s:
        if (c == 'a') or (c == 'e') or (c == 'i') or (c == 'o') or (c == 'u'):
            risultato = risultato + 1
    return risultato

print(conta_vocali('tanto va la gatta al ladro'))
print(conta_vocali('tnt v l gtt l lrd'))
print(conta_vocali('tAntO va la gatto al ladro'))
