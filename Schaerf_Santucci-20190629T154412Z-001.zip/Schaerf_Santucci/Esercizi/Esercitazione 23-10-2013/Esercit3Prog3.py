import math

def stesso_vettore(lista1, lista2):
    if (len(lista1) != len(lista2)):
        return False
    else:
        for i in range(1, len(lista1)):
            #if ((lista1[i] / lista2[i]) != (lista1[0] / lista2[0])):
            if (math.fabs((lista1[i] / lista2[i]) - (lista1[0] / lista2[0]))
                > 0.001):
                return False
    return True

l1 = [1, 1.5, 2]
l2 = [2, 3, 4]
l3 = [0.5,0.75,1]
l4 = [3, 4.5, 7]
l5 = [1, 1.5, 2, 2.5]

print(l1,l2,stesso_vettore(l1,l2))
print(l1,l3,stesso_vettore(l1,l3))
print(l2,l3,stesso_vettore(l2,l3))
print(l1,l4,stesso_vettore(l1,l4))
print(l1,l5,stesso_vettore(l1,l5))
