def somma(l1, l2):
    nuova = []
    for i in range(len(l2)):
        if (i < len(l1)):
            nuova += [l1[i] + l2[i]]
        else:
            nuova += [l2[i]]
    return nuova    

def sommaListe(lista1, lista2):
    if (len(lista1) < len(lista2)):
        return somma(lista1, lista2)
    else:
        return somma(lista2, lista1)

lista1 = [1,3,5,7]
lista2 = [3,5,6,11]
lista3 = [4,5]
lista4 = [3,6,7,9,11]

print(lista1,lista2,sommaListe(lista1,lista2))
print(lista1,lista3,sommaListe(lista1,lista3))
print(lista1,lista4,sommaListe(lista1,lista4))
