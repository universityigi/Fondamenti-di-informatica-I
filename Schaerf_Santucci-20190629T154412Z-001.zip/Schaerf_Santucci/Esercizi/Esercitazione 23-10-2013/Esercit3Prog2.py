def primaPosizione(lista, stringa):
    posizione = max(map(len, lista))
    
    # La funzione map(f, oi), applica la funzione(f) all'oggetto iterabile(oi).
    # Cioè esegue un ciclo for per tutta la lunghezza dell'oggetto (lista, etc)
    # applicando la funzione(f) ad ogni elemento dell'oggetto(oi).

    # In questo caso, a 'posizione' si assegna la lunghezza dell'elemento
    # più grande della lista.
    
    elemento = ''
    for el in lista:
        if ((el.find(stringa) < posizione) and (el.find(stringa) != -1)):
            posizione = el.find(stringa)
            elemento = el
    return elemento


l = ['quattro tiri', 'cinque tigri', 'tre tigri']
print(l,'tigri',primaPosizione(l,'tigri'))
