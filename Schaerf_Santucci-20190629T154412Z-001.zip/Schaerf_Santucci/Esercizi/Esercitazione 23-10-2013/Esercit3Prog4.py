def trovaIndirizzoNumero(indirizzario,nome):
    if (indirizzario.find(nome) == -1):
        return -1
    else:
        risultato = indirizzario.splitlines()
        for elemento in risultato:
            if (elemento.find(nome) != -1):
                prova = elemento.split(';')
                risultato = [prova[1]] + [prova[2]]
                return risultato

indi = '''Marco;Via delle palme 11;0677777777
Paolo;Via delle rose;34444444444
Maria;Piazza Dante; 06 77999999'''

print('Marco', trovaIndirizzoNumero(indi,'Marco'))
print('Paolo', trovaIndirizzoNumero(indi,'Paolo'))
