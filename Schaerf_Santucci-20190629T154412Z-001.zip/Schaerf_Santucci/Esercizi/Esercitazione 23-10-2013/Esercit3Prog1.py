def ripetuta(lista, stringa, intero):
    nuova = []
    for elemento in lista:
        if (elemento.count(stringa) >= intero):
            nuova += [elemento]
    return nuova

l1 = ['pippo','pappa','prova']

print(l1, 'p', 3, ripetuta(l1,'p',3))
