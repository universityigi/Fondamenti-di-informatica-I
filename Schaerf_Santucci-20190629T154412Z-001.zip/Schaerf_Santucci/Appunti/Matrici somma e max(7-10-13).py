import random




def CreaMatriceCasuale(r,c):
    m=[]
    for i in range(r):
        m+=[[]]
        for j in range(c):
            m[i]+=[random.randint(1,100)]
    return m
#print(CreaMatriceCasuale(3,4))

def StampaMat(m):
    for i in range(len(m)):
        print('\n')
        for j in range (len(m[i])):
            print(m[i][j],'     ', end='')
    return ''

def StampaMat2(m):
    for riga in m:
        print('\n')
        for el in riga:
            print(el,'    ', end=' ')
    return ''


file=0
m1=CreaMatriceCasuale(3,4)
m2=CreaMatriceCasuale(3,4)
r=3
c=4
def sommaMat(m1,m2,file):
    m=[]
    #Dovevo mettere il nome file e farla scrivere ma non mi andava LOL
    a=0
    if len(m1)==len(m2):
        for i in range(len(m1)):
            if len(m1[i])==len(m2[i]):
                a=True
    else:
        print('Le matrici devono essere uguali')            
    if a==True:
        for i in range(len(m1)):
            m+=[[]]
            for j in range(len(m1[i])):
                m[i]+=[m1[i][j]+m2[i][j]]
    
    else:
        print('ciao')
    return m
print(StampaMat(sommaMat(m1,m2,file)),'\n')
print(StampaMat2(m1))
print(StampaMat2(m2))


def massimoMat(m):
    massimo=-10
    for riga in m:
        for el in riga:
            if el>massimo:
                massimo=el
    return massimo
print('\nIl massimo della matrice m1 è:',massimoMat(m1))
print('\nIl massimo della matrice m2 è:',massimoMat(m2))
print('\nIl massimo della matrice m è:',massimoMat(sommaMat(m1,m2,file)))
