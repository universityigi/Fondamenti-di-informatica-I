def trovaMin(l):
    if len(l) > 0:
        minimo = l[0]
    else:
        return None 
    for i in l:
        if i < minimo:
            minimo = i
    return minimo

lista1 = [7, 5, 9, 3, 12, 4]
lista2 = [-7, -5, -9, -3, -12, -4]
lista3 = []

print(lista1,trovaMin(lista1))
print(lista2,trovaMin(lista2))
print(lista3,trovaMin(lista3))
