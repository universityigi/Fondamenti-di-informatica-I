def trovaPosMax(l):
    posMassimo  = -1
    massimo = 0
    for i in range(len(l)):
        if l[i] > massimo:
            massimo = l[i]
            posMassimo = i
    return posMassimo

lista = [7, 5, 9, 3, 12, 4]
print(trovaPosMax(lista))
