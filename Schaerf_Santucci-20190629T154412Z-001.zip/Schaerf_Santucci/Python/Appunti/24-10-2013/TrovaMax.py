def trovaMax(l):
    if len(l) > 0:
        massimo = l[0]
    else:
        return None 
    for i in l:
        if i > massimo:
            massimo = i
    return massimo

lista1 = [7, 5, 9, 3, 12, 4]
lista2 = [-7, -5, -9, -3, -12, -4]
lista3 = []

print(lista1,trovaMax(lista1))
print(lista2,trovaMax(lista2))
print(lista3,trovaMax(lista3))
