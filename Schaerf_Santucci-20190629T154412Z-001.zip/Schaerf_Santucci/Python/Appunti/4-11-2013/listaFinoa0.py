def listaFinoa0(nomeFile):
    lista = []
    f = open(nomeFile, 'r')
    riga = f.readline()
    while int(riga) != 0:
        lista += [int(riga)]
        riga = f.readline()
    f.close()
    return lista





nome = "C:\\Users\\Andrea\\Desktop\\ex1.txt" #modificare il percorso del file ex1.txt
print(listaFinoa0(nome))
