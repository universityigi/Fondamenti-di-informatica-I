def listaFinoa0(nomeFile):
    lista = []
    f = open(nomeFile, 'r')
    riga = f.readline()
    while (riga != '') and (int(riga) != 0):
        lista += [int(riga)]
        riga = f.readline()
    else:
        print (riga)
    f.close()
    return lista





nome = "C:\\Users\\Andrea\\Desktop\\ex3.txt" #modificare il percorso del file ex3.txt

print(listaFinoa0(nome))








