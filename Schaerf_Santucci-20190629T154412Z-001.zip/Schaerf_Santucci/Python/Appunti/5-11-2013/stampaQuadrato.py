def stampaQuadrato(n):
    for i in range(n):
        for j in range(n):
            print(' * ', end = ' ')
        print()

stampaQuadrato(4)
stampaQuadrato(5)
stampaQuadrato(20)
