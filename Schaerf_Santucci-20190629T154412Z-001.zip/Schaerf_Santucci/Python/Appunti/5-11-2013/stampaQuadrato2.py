def stampaQuadrato(n,s):
    for i in range(n):
        for j in range(n):
            print(s, end = ' ')
        print()

stampaQuadrato(5,'!')
stampaQuadrato(20,'%')
