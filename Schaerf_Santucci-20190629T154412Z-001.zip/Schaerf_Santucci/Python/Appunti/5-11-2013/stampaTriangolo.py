def stampaTriangolo(n,s):
    for i in range(n):
        for j in range(i + 1):
            print(s, end = '')
        print()

stampaTriangolo(5, '!')

