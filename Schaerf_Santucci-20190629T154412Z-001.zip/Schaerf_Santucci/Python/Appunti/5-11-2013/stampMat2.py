def stampaMat(m):
    for riga in m:
        for elem in riga:
            print(elem)

mat = [[1, 5, 7],[0, 3, 4],[2, 1, 0]]
stampaMat(mat)
