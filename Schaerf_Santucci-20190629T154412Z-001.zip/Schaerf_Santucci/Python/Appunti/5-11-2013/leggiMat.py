def LeggiMat(file):
    f = open(file, 'r')
    m = []
    for elem in f:
        m += [elem.strip().split(' ')]
    f.close()
    return m


print(LeggiMat('C:\\Users\\Andrea\\Desktop\\prova3.txt'))
