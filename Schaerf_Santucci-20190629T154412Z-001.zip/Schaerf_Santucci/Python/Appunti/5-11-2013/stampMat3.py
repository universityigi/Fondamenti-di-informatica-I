def stampaMat(m):
    for riga in m:
        for elem in riga:
            print(elem, '\t' ,end = "")
        print()

mat = [[11, 5312, 7],[0, 3, 4],[232, 1, 123450]]
stampaMat(mat)
