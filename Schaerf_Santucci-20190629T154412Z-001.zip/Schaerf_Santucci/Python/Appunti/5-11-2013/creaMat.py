import random
def creaMat(n):
    m = []
    for i in range(n):
        m += [[]]
        for j in range(n):
            m[i] += [random.randint(0, 100)]
    return m

def stampaMat(m):
    for riga in m:
        for elem in riga:
            print(elem, '\t' ,end = "")
        print()

mat = [[11, 5312, 7],[0, 3, 4],[232, 1, 123450]]
mat2 = creaMat(7)
print(mat2)
stampaMat(mat2)
