def stampaTriangoloDestra(n,s):
    for i in range(n):
        for j in range(n):
            if i + j >= (2*n - 1):
                print(s, end = '')
            else:
                print(' ',end = '')
        print()

stampaTriangoloDestra(5, '*')

