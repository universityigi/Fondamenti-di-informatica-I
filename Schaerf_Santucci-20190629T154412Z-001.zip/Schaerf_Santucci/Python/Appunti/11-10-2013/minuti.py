eta1 = eval(input("Inserisci i tuoi anni "))
eta2 = eval(input("Inserisci gli anni di un altro"))
def anni(eta1,eta2):
    if eta1==eta2:
        print('Io e te abbiamo gli stessi anni')
    if eta1>=eta2:
        print('Tu hai piu anni di me')
    if eta1<=eta2:
        print('Io ho piu anni di te')
        return anni(eta1,eta2)
