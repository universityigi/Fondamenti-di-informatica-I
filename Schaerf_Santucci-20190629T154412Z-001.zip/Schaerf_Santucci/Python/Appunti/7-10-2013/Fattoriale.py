def f (n):
    if n==0:
        return 1
    n=n*f(n-1)
    return n
print (f(99992019))