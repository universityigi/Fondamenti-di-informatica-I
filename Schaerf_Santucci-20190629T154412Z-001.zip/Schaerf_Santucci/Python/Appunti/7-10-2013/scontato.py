prezzo=eval(input("inserire il prezzo dell'articolo "))
sconto=eval(input("inserire lo sconto da applicare "))
def scontato():
    dif=prezzo/100*sconto
    nuovo_prezzo=prezzo-dif
    return nuovo_prezzo

print ("il prezzo scontato è %u" % scontato())
