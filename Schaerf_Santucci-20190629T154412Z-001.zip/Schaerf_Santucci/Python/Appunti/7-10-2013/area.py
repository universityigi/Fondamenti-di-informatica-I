def area (raggio):
  return raggio **2
