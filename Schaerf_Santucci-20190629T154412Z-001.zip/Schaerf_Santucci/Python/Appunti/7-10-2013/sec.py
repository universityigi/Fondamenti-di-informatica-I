def sec(hh,mm,ss):
    ss1= hh *3600 + mm *60 +ss
    return (ss1)
#allora hh mm e ss sono le cose da inserire, nb non dare ai secondi di ritorno e ai secondi
#di input lo stesso nome
#adesso demo metteree prin perchè non posso interagire con la console

print (sec(343433, 4365, 2435))


