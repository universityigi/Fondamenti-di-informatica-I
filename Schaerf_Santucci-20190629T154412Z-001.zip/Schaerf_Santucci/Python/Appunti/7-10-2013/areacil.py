def areacil (r, h):
    pigreco=22/7
    area = pigreco*(r**2)
    circonferenza=2 * pigreco *r
    return 2*area + h *circonferenza

print (areacil(5,60), areacil(3435,32))

