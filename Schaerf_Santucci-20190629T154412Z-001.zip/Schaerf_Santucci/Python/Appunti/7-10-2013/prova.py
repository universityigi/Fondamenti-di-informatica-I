def areaCilindro(raggio, altezza):
    pigreco = 3.14159
    area = pigreco*(raggio**2)
    circonferenza = 2*pigreco*raggio
    return 2*area + altezza*circonferenza
print (areaCilindro(10, 5), areaCilindro(20, 10))
