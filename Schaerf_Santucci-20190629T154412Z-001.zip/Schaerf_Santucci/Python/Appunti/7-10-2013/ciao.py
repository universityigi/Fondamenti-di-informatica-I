def c (minuti):
  #Voglio definire una funzione che calcoli i minuti in ore minuti e secondi
  print ("I minuti che hai scritto in ore sono")
  return minuti / 60, minuti  %60, minuti %60 %60
  