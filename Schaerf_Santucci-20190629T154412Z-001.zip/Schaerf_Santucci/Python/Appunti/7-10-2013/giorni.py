def tempo(ss):
    mm = ss//60
    ss1= ss%60
    #ss1 =secondi rimanenti
    hh=mm//60
    #mm1=minuti rimanenti
    mm1=mm%60
    dd=hh//24
    hh1=hh%24
    

    return dd, hh1, mm1,ss1
1
print ("Il risultato è %u giorni %u ore %u minuti e %u secondi" % tempo(86400))
#per usare il %u devo mettere la funzione in questo caso
