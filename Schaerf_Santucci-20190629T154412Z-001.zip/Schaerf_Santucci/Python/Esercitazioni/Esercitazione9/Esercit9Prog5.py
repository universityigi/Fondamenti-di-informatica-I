def calcolaClassifica(file):
# scrivere la funzione

p = "C:\\documenti\\ProgPython\\campionato.txt"
d = calcolaClassifica(p)

# Stampa tutti gli elementi del dizionario in ordine alfabetico
l=list(d.keys())
l.sort()
for elem in l:
    print(elem, d[elem])

