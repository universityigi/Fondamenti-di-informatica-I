def calcolaDebiti(file):
# scrivere la funzione

p = "C:\\documenti\\ProgPython\\vincite.txt"
d = calcolaDebiti(p)

# Stampa tutti gli elementi del dizionario in ordine alfabetico
l=list(d.keys())
l.sort()
for elem in l:
    print(elem, d[elem])

