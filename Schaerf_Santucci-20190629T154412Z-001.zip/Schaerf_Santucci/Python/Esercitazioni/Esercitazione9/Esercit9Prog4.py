def ricercaBinaria(v,el):
    start=0
    stop=len(v)
    trovato=False
    cicli=0
  


def creaLista(n):
    import random
    v=[(10**16)//2]
    for i in range(n-1):
        v+=[random.randint(1,9999999999999999)]
    return v    






#----------------
l=creaLista(6)            
l.sort()
print(ricercaBinaria(l,55555))
print(ricercaBinaria(l,(10**16)//2))
print("Cerco il primo elemento", ricercaBinaria(l,l[0]))
print("Cerco l'ultimo elemento",ricercaBinaria(l,l[len(l)-1]))


