def frasi(p):
    import re
    p=open("/home/federico/Documents/Università/Python/Esercitazioni/Es 9/IMalavoglia.txt", encoding="utf-8").read()
    stri=''
    parole=p.split('\'')
    for el in parole:
        stri+=el+' '
    stringa=stri.split()
    #print(str)
    massimo=''
    minimo='asfdadefwaefewagersrtudwfewra'
    #print(parole)
    for el in stringa:
        if len(el)>=len(massimo):
           massimo=el
        if len(el)<=len(minimo):
            minimo=el
    #print(massimo)
    

    #return piùCorta,piùLunga,nFrasi,media    
    return massimo,minimo








p=open("/home/federico/Documents/Università/Python/Esercitazioni/Es 9/IMalavoglia.txt", encoding="utf-8").read()

print(frasi(p))

#v=frasi(p)
