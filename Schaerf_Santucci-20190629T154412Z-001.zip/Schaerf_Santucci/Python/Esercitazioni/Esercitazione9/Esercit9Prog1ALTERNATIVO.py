#pattern=input("pattern? (digita ' end' per terminare) ")
def frasi(p):
    import re
   
    pattern='\W\w+'
    s=re.findall(pattern,p)
    print(s)
    massimo=''
    for el in s:
        if len(el)>len(massimo):
            massimo=len(el)
            piùLunga=el
    s.sort()
    print ("s=re.findall('"+pattern+"',p)",len(s), "match trovati")   
    return piùCorta,piùLunga,nFrasi,media    
    







p=open("/home/federico/Documents/Università/Python/Esercitazioni/Es 9/IMalavoglia.txt", encoding="utf-8").read()

print(frasi(p))

v=frasi(p)
