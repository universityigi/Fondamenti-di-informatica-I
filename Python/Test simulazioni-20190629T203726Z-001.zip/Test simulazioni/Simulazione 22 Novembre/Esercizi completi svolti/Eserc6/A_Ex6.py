def A_Ex6(file):
    f=open(file, encoding="UTF-8")
    s=f.read()
    f.close()
    l=s.split("\n")
    l1=[]
    l2=[]
    l3=[]
    n=1
    numeropersone=0
    persona="Nessuno dei presenti"
    crescita=0
    for elem in l:
        if elem!="":
            
                if n==1:
                    l1.extend(elem.split(","))
                    numeropersone=len(l1)
                    n+=1
                elif n==2:
                    l2.extend(elem.split(","))
                    numeropersone=len(l2)
                    n+=1
                elif n==3:
                    l3.extend(elem.split(","))
                    numeropersone=len(l3)
    for n in range(0,numeropersone):
        print(l3[n], l2[n])
        if int(l3[n])-int(l2[n])>crescita:
            persona=l1[n]
            crescita=int(l3[n])-int(l2[n])
    return persona
                
       

#non cancellare
print(A_Ex6("altezze1.txt"))
        
