def A_Ex3(s):
    indiceparola=0
    l=[]

    for i in range(0,len(s)):
       
        if s[i]==" " and s[indiceparola:i] not in l:
            l.append(s[indiceparola:i])
            indiceparola=i+1
        elif s[i]==" " and s[indiceparola:i] in l:
            indiceparola=i+1
        if i==len(s)-1 and s[i]!=" " and s[indiceparola:i+1] not in l:
            l.append(s[indiceparola:i+1])

            

    return l

#non cancellare
print(A_Ex3("tanto va la gatta al lardo che ci lascia la zampina"))
