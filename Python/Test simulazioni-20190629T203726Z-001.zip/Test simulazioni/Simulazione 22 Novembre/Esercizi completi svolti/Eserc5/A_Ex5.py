def A_Ex5(file):
    f=open(file, encoding="UTF-8")
    s=f.read()
    f.close()
    l=s.split("\n")
    l1=[]
    l2=[]
    somma=0
    
    for elem in l:
        l1=elem.split(" ")
        for n in l1:
            if n!="":
                somma+=int(n)
        if n!="":
            l2.append(somma)
            somma=0
    
    
    return l2

#non cancellare
print(A_Ex5("interi1.txt"))
