#
def isInteger(s):
    if len(s) > 0 and (s.isdecimal() or (s[0] in '+-' and s[1:].isdecimal())):
        return True
    else:
        return False

def isReal(s):
    if isInteger(s):
        return True
    k = s.find('.')
    if k == -1:
        return False
    intera = s[0:k]
    decimale = s[k+1:]
    return isInteger(intera) and decimale.isdecimal()
    
def pulisciFile(file,ammissibili='0123456789abcdefghijklmnopqrstuvxywz'):
    f=open(file,encoding="UTF-8")
    stopList = ''
    s=f.read()
    f.close()
    for elem in s:
        elem = elem.lower()
        if elem not in ammissibili and elem not in stopList:
           stopList += elem
    #print(stopList)       
    for c in stopList:
        s = s.replace(c,' ')
    while s.find('  ') >= 0:
        s = s.replace('  ',' ')
    return s

def rimuoviDoppioni(l):
    nuova = []
    for elem in l:
        if elem not in nuova:
            nuova.append(elem)
    return nuova
