from libreriaV2 import *
def A_Ex1(file,c):
    s=pulisciFile(file, ammissibili="0123456789abcdefghijklmnopqrstuvwxyz")
    l=s.split(" ")
    l1=[]
    for elem in l:
        if (c.lower() in elem) or (c.upper() in elem):
            
                l1.append(elem)
    return l1



#Non modificare
print(A_Ex1("IMalavoglia.txt",'j'))
