def A_Ex2(file,s):
    f=open(file,encoding="UTF-8")
    s1=f.read()
    f.close()
    l=s1.split("\n")
    n=0
    print(l)
    for elem in l:
        if s in elem:
            n+=1
    return n


#Non modificare
print(A_Ex2("file1.txt",'capra'))
    
