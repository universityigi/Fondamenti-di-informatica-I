def A_Ex4(file):
    f=open(file, encoding="UTF-8")
    s=f.read()
    f.close()
    l=s.split("\n")
    l1=[]
    print(s)
    
    for elem in l:
        if " " in elem:
            l1=elem.split(" ")
        else:
            l1=l
    maggiore=l1[0]
    minore=l1[0]
    for elem in l1:
        if elem>maggiore:
            maggiore=elem
        elif elem<minore:
            minore=elem
    return int(minore),int(maggiore)


#non cancellare
print(A_Ex4("interi1.txt"))
