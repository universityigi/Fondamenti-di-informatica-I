def A_Ex2(file,s):
    return None

#Non modificare
print(A_Ex2("file1.txt",'capra'))
    
