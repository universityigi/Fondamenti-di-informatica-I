def A_Ex6(file):
    return None

#non cancellare
print(A_Ex6("altezze1.txt"))
        
