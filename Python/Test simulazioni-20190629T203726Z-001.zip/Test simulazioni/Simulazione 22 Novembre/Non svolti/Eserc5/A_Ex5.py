def A_Ex5(file):
    return None

    

#non cancellare
print(A_Ex5("interi1.txt"))
