from libreriaV2 import *
def A_Ex1(file,c):
    return None

#Non modificare
print(A_Ex1("IMalavoglia.txt",'j'))
