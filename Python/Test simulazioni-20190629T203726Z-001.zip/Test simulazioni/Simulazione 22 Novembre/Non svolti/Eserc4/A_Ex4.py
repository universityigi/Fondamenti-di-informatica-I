def A_Ex4(file):
    return None
    


#non cancellare
print(A_Ex4("interi1.txt"))
