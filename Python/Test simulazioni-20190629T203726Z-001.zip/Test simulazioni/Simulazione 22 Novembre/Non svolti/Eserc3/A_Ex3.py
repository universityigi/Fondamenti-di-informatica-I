def A_Ex3(s):
    return None

#non cancellare
print(A_Ex3("tanto va la gatta al lardo che ci lascia la zampina"))
