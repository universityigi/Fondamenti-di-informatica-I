def A_Ex1(s1,s2):
    lettuguali=0
    if len(s1)>len(s2):
        maxnum=len(s2)
    else:
        maxnum=len(s1)
    for i in range(maxnum):
        if s1[i]==s2[i]:
            lettuguali+=1
        else:
            return lettuguali
    return lettuguali

#Non modificare
print(A_Ex1('Pippo','Paperopoli'))
