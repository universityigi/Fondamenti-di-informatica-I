import sys
import os
import py_compile

def timelimit(timeout, func, args=(), kwargs={}):
    import threading
    class FuncThread(threading.Thread):
        def __init__(self):
            threading.Thread.__init__(self)
            self.result = None
        def run(self):
            self.result = func(*args, **kwargs)
    it = FuncThread()
    it.start()
    it.join(timeout)
    if it.isAlive():
        return "\nIl tuo programma sta eseguendo un ciclo infinito.\nPer ucciderlo non basta premere invio\n devi chiudere la finesta con il mouse"
    else:
        return it.result

d=os.getcwd()
if d[0:-1]!="T:\\Esame\\Eserc" and False:
    print("Attenzione: stai salvando il tuo compito su una cartella sbagliata\n Contatta il docente")
    

f=open("config.txt","r", encoding="UTF8")
for i in range(6):
    s=f.readline().strip()
try:    
    print("Compilo ",s)
    py_compile.compile(s,doraise=True)
except py_compile.PyCompileError:
    tb=sys.exc_info()[2]
    tbb=tb.tb_next
    tbbb=tbb.tb_next
    print("Si è verificato un errore di compilazione")
    #print(sys.exc_info()[0])
    print(sys.exc_info()[1])
    tb=sys.exc_info()[2]
    h=input("Premere invio per terminare...")
    sys.exit()
try:    
    exec("import "+s[0:len(s)-3])
    #print("import "+s[0:len(s)-3])
    metodoStu=s[0:len(s)-3]
    s=f.readline().strip()
    s=f.readline().strip()
    exec("import "+s[0:len(s)-3])
    #print("import "+s[0:len(s)-3])
    metodoDoc=s[0:len(s)-3]
    s=f.readline().strip()
    s=f.readline().strip()
    metodoStu+="."+s
    metodoDoc+="."+s
    while s[0]!="(":
        s=f.readline().strip()
    s.strip()
    print("========================")
    print(metodoStu[6:]+s)
    print("========================")
    exec("doc="+metodoDoc+s)
    print("Il risultato giusto: ",doc,"\n***********")    

    command="stu=timelimit(3,"+ metodoStu+", ["+s[1:-1]+"])"
    exec(command)
    #exec("stu="+metodoStu+s)

    print("Il tuo risultato: ", stu,"\n***********")
    
    if stu==doc:
        print("Il tuo risultato è giusto!")
    else:
        print("Il tuo risultato è sbagliato!")
    print("--------------------------------------------")   
    f.close()
    if d[0:-1]!="T:\\Esame\\Eserc" and False:
        print("Attenzione: stai salvando il tuo compito su una cartella sbagliata\n Contatta il docente")
    

except BaseException:
    tb=sys.exc_info()[2]
    tbb=tb.tb_next
    tbbb=tbb.tb_next
    print("Durante l'esecuzione del tuo codice")
    print("si è verificato un errore alla linea:", tbbb.tb_lineno)
    #print(sys.exc_info()[0])
    print(sys.exc_info()[1])
    tb=sys.exc_info()[2]
if d[0:-1]!="T:\\Esame\\Eserc" and False:
    print("Attenzione: stai salvando il tuo compito su una cartella sbagliata\n Contatta il docente")
    
    
h=input("Premere invio per terminare...")      
