def A_Ex5(file_in,file_out):
    #creare il file file_out
    fin=open(file_in,"r",encoding="UTF-8")
    l=[]
    riga=fin.readline().strip().split(";")
    n=0
    while len(riga)>0 and riga[0]!="":
        print(riga)
        l.append(0)
        for elem in riga:
            
            l[n]=int(l[n])+int(elem)
        n+=1
        riga=fin.readline().strip().split(";")
    fin.close()
    fout=open(file_out,"w",encoding="UTF-8")
    
    print(l)
    for elem in l:
        print(elem)
        
        print(str(elem) , file=fout)
    
    fout.close()
    
    
    


    #non modificare l'istruzione seguente
    return open(file_out,"r",encoding="UTF-8").readlines()

