def A_Ex4(l,fileName):
    #creare il file
    lunga=""
    corta=l[0]
    for i in range(len(l)):
        if len(l[i])>len(lunga) and len(l[i])>0:
            lunga=l[i]
        elif len(l[i])<len(corta):
            corta=l[i]
    fout=open(fileName,"w",encoding="UTF-8")
    print(corta+"\n"+lunga,file=fout)
    fout.close()


    #non modificare
    s=open(fileName,"r",encoding="UTF-8").readlines()
    print(s)
    return s

#non modificare
f=open("stringhe.txt",'w',encoding='UTF-8')
f.close()
print(A_Ex4(['sellino', 'trota', 'il', 'stringa molto lunga'],"stringhe.txt"))

    
