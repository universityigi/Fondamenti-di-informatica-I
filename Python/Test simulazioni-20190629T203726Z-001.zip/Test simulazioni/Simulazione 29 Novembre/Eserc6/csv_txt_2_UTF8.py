import os
for file in os.listdir():
    if file.endswith(".csv") or file.endswith(".txt"):
        print('Processing ',file)
        l= open(file).readlines()
        fout=open(file,'w',encoding='utf-8')
        for elem in l:
            print(elem.strip(),file=fout)
        fout.close()
