def A_Ex6(fileName,nome):
    fin=open(fileName,"r",encoding="UTF-8")
    riga=fin.readline().strip().split(",")
    riga=fin.readline().strip().split(",")
    amici=[]
    while len(riga)>0 and riga!=[""]:
        if riga[0]==nome and riga[2]=="amici":
            amici.append(riga[1])
        elif riga[1]==nome and riga[2]=="amici":
            amici.append(riga[0])
        elif riga[0]==nome and (riga[1] in amici) and riga[2]=="nemici":
            amici.remove(riga[1])
        elif riga[1]==nome and (riga[0] in amici) and riga[2]=="amici":
            amici.remove(riga[0])
        riga=fin.readline().strip().split(",")
        amici.sort()
    return amici
    
    

print(A_Ex6('amici1.csv','Paolo'))
