def A_Ex2(start,n):
    somma=0
    if start%2==1:
        numstart=start
    else:
        numstart=start+1
    for n1 in range(n):
        somma+=(numstart+(2*n1))
    return somma

#Non modificare
print(A_Ex2(5,2))
    
