def A_Ex3(l,n):
    n1=0
    for elem in l:
        if int(elem)>n:
            n1+=1
    return n1

#non cancellare
print(A_Ex3([3, 5, 2, -8, 7],2))
