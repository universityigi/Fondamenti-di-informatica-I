def A_Ex4(s,c, start = 0, end = None):
    
    indice=-1
    
    if end != None:
        for n in range(0, len(s)-len(c)+1-(len(s)-int(end))):
        
            if s[n:n+len(c)]==c and n>indice:
            
                indice=n
    else:
        for n in range(0, len(s)-len(c)+1):
        
            if s[n:n+len(c)]==c and n>indice:
                
                indice=n
            
    return indice

print(A_Ex4("casacasa","asa",0,4))

print(A_Ex4('Casaletto','a',0,2))

