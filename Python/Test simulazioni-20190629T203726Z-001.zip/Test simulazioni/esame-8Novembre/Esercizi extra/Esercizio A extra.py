def composta(s1,s2):
    l=[]
    l.extend(s2)
    s=""
    for elem in s1:
        if elem not in l:
            s=s+elem
    return s






print(composta(input("Inserisci una prima parola: "),input("Inserisci una seconda stringa: ")))


