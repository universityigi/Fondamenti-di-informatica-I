def distanzalettere(s):
    distanzatot=0
    for i in range(0, len(s)):
        for i2 in range(i,len(s)-i):
            if s[i]==s[i2]:
                carattere=s[i]
                distanza=i2-i
                if distanzatot<distanza:
                    distanzatot=distanza
    return distanzatot

def distanzalettereeconomica(s):
    distanzatot=0
    for i in range(0, len(s)):
        distanza=s.rfind(s[i])-i
        if distanza>distanzatot:
            distanzatot=distanza
    return distanzatot

print("La distanza maggiore tra due lettere è di", distanzalettere(input("Inserisci una parola: ")),"caratteri")

print("ECO || La distanza maggiore tra due lettere è di", distanzalettereeconomica(input("Inserisci una parola: ")),"caratteri")
