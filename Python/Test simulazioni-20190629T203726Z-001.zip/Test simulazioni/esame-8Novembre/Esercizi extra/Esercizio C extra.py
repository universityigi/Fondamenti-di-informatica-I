def lettereuguali(s,n):
    n=int(n)
    for i in range (0, len(s)):
        if i+n<len(s) and s[i]==s[i+n]:
            return True
    return False


print("Lettere uguali a distanza da te specificata presenti ? ",lettereuguali(input("Inserisci una stringa: "),input("Inserisci un numero intero: ")))
