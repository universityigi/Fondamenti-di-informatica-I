def crescente(s):
    prec=s[0]
    for i in range(1,len(s)):
        if s[i]>prec:
            prec=s[i]
        else:
            prec=s[i]
            return False
    return True
    
print(crescente("abelpo"))
