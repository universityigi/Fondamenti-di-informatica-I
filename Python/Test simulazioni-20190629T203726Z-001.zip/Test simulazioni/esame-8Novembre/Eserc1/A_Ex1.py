def A_Ex1(s1,s2):
    s=""
    for n in range(0,len(s1)):
        s=s+s1[n]+s2[n]
    return s


#Chiamata di prova - Non modificare
print(A_Ex1('cs','aa'))
