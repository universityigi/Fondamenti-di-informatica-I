def A_Ex3(s,n):
    s1=""
    for n1 in range(0, len(s)):
        s1=s1+(s[n1]*n)
    return s1






#Chiamata di prova - Non modificare
print(A_Ex3('pippo',2))
