def A_Ex2(s):
    maxcar=""
    indice=-1
    nripetizioni=-1
    for n in range(0,len(s)):
        if 97<=ord(s[n])<=122 and s.count(s[n])>nripetizioni:
            maxcar=s[n]
            indice=n
            nripetizioni=s.count(s[n])
        elif 97<=ord(s[n])<=122 and s.count(s[n])==nripetizioni and n<indice:
            maxcar=s[n]
            indice=n
            nripetizioni=s.count(s[n])
            

    return maxcar



print(A_Ex2('Paperina'))




#Chiamata di prova - Non modificare
print(A_Ex2('Paperopoli'))
    
