def contaParole(s):
    s=s.split()
    return len(s)
    
    

def parolaPiuFrequente(s):
    s1=s.split()
    n=0
    i=0
    for i in range(0,len(s1)):
        if s1.count(s[i])>n:
            n=s1.count(s[i])
            indice=i
    return s[indice]

def frasePiuCorta(s):
    s1=s.split(".")
    n=len(s1[0])
    frase=s1[0]
    for elem in s1:
        if len(elem)<n:
            n=len(elem)
            frase=elem
    return frase
            


s="Questo racconto è lo studio sincero e spassionato del come probabilmente devono nascere e svilupparsi nelle più umili condizioni le prime irrequietudini pel benessere; e quale perturbazione debba arrecare in una famigliuola, vissuta sino allora relativamente felice, la vaga bramosìa dell'ignoto, l'accorgersi che non si sta bene, o che si potrebbe star meglio.Il movente dell'attività umana che produce la fiumana del progresso è preso qui alle sue sorgenti, nelle proporzioni più modeste e materiali. Il meccanismo delle passioni che la determinano in quelle basse sfere è meno complicato, e potrà quindi osservarsi con maggior precisione. Basta lasciare al quadro le sue tinte schiette e tranquille, e il suo disegno semplice. Man mano che cotesta ricerca del meglio di cui l uomo è travagliato cresce e si dilata, tende anche ad elevarsi, e segue il suo moto ascendente nelle classi sociali.Nei Malavoglia non è ancora che la lotta pei bisogni materiali. Soddisfatti questi, la ricerca diviene avidità di ricchezze, e si incarnerà in un tipo borghese, Mastro–don Gesualdo, incorniciato nel quadro ancora ristretto di una piccola città di provincia, ma del quale i colori cominceranno ad essere più vivaci, e il disegno a farsi più ampio e variato. Poi diventerà vanità aristocratica nella Duchessa de Leyra; e ambizione nell'Onorevole Scipioni, per arrivare all'Uomo di lusso, il quale riunisce tutte coteste bramosìe, tutte coteste vanità, tutte coteste ambizioni, per comprenderle e soffrirne, se le sente nel sangue, e ne è consunto"
print(contaParole(s))
print(parolaPiuFrequente(s))
print(frasePiuCorta(s))
