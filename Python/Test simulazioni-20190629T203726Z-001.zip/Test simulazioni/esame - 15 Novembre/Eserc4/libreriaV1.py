def isPari (n):
    return n%2==0

def isDispari (n):
    return n%2==1

def isInteger (s):
    if s[0:1] in "+-":
        s=s[1:]
    return s.isdecimal()

def isReal (s):
    if s[0:1] in "+-":
        s=s[1:]          
    return s.isdecimal() or (s.count(".")==1
                             and s.replace(".","1").isdecimal())


