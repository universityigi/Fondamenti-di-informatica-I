def A_Ex4(l,n):
    l2=[]
    for elem in l:
        if len(elem)>=n:
            l2.append(elem)
    return l2
    


#chiamata di prova della funzione. NON modificare
print(A_Ex4( ['pippo', 'a', '', 'casa', 'legna'],3))
