def A_Ex2(start,n):
    if start%2!=1:
        numiniz=start+1
    else:
        numiniz=start
    risultato=numiniz
    for i in range(1,n):
        risultato=risultato+(numiniz+(2*i))
    return risultato



#chiamata di prova della funzione. NON modificare
print(A_Ex2(4,3))
