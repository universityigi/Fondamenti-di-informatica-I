def A_Ex5(s,n):
    if len(s)==0:
        l=[]
        return l
    s1=s.split(" ")
    n2=0
    l=[]
    for i in range(0,len(s1)):
        if s.count(s1[i])>n:
            if s1[i] not in l:
                l.append(s1[i])
                l.sort()
    return l

#chiamata di prova della funzione. NON modificare
print(A_Ex5('il cane il gatto e il topo',2))







    
