def A_Ex3(l,n):
    s=""
    for elem in l:
        if n<=(len(elem)-1):
            s=s+elem[n]
        else:
            s=s+"!"
    return s

print(A_Ex3( ['nel', 'mezzo', 'del', 'cammin', 'di', 'nostra', 'vita', 'mi', 'ritrovai'],0))

#chiamata di prova della funzione. NON modificare
print(A_Ex3( ['tanto', 'va', 'la', 'gatta', 'al', 'lardo'],2))
