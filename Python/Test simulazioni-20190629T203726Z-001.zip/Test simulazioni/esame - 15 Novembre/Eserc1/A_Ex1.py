def A_Ex1(s1,s2):
    if len(s1)>len(s2):
        maxnum=len(s2)
    else:
        maxnum=len(s1)
    s=""    
    for i in range(0, maxnum):
        if s1[i]==s2[i] and s1[i] not in s:
            s=s+s1[i]
    return s



#chiamata di prova della funzione. NON modificare
print(A_Ex1('castana','cessata'))
