def A_Ex4(file):
    filein= open(file, "r", encoding="UTF-8")
    righe=filein.readlines()
    diz={}
    for riga in righe:
        riga=riga.strip().split(";")
        nome=riga[0]
        quota=int(riga[1])
        tipo=riga[2]
        if tipo=="versamento":
            if nome not in diz:
                diz[nome]=quota
            else:
                diz[nome]+=quota
        elif tipo=="prelievo":
            if nome not in diz:
                diz[nome]=0-quota
            else:
                diz[nome]-=quota
        elif tipo=="tasse":
            if nome in diz and diz[nome]>0:
                diz[nome]-=((diz[nome]/100)*quota)
    for elem in diz:
        diz[elem]=int(diz[elem])
    return diz
                

#non modificare
print(A_Ex4('file1.txt'))
    
