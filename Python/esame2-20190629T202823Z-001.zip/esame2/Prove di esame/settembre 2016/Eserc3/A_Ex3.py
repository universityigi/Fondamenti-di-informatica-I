def A_Ex3(file):
    filein = open(file, "r", encoding="UTF-8")
    parola=filein.readline().strip()
    diz={}
    while len(parola)>0:
        if len(parola)>1:
            if parola[:2] not in diz:
                diz[parola[:2]]=[parola,1]
            else:
                diz[parola[:2]][0]=parola
                diz[parola[:2]][1]+=1
        parola=filein.readline().strip()
    return diz
        

#non modificare
print(A_Ex3('file1.txt'))
