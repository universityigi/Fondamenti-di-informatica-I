def A_Ex4(file):
    fin = open(file, "r", encoding="UTF-8")
    righe=fin.readlines()
    diz={}
    for riga in righe:
        riga=riga.strip()
        if riga != "":
            riga=riga.split(";")
            
            if riga[2]=="apertura":
                diz[riga[0]]=int(riga[1])
            elif riga[2]=="prelievo":
                diff=diz[riga[0]]-int(riga[1])
                diz[riga[0]]=diff
            elif riga[2]=="versamento":
                somma=diz[riga[0]]+int(riga[1])
                diz[riga[0]]=somma
            print(diz)
    maggiore=""
    conteggio=0
    for elem in diz:
        if diz[elem]>conteggio:
            maggiore=elem
            conteggio=diz[elem]
        elif diz[elem]==conteggio:
            if elem<maggiore:
                maggiore=elem
                conteggio=diz[elem]
    if diz=={}:
        return []
    return maggiore
        
#non modificare
print(A_Ex4('saldi1.txt'))
