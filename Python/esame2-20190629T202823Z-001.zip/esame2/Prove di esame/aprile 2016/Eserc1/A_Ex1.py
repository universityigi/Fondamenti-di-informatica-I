def A_Ex1(s):
    ripetizioni = 0
    choice = ""
    risultato=""
    for letter in s:
        num = s.count(letter)
        if num>ripetizioni:
            choice = letter
            ripetizioni = num
    if len(s)>1:
        risultato= choice + s[-1]
    return risultato

#non modificare
print(A_Ex1('caso palese'))
