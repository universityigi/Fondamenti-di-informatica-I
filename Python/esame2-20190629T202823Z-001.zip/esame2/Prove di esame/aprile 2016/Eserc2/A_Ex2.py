def A_Ex2(l):
    l1=[]
    for n in l:
        if n%2==1 or n<0:
            l1.append(n)
    l1.sort()
    return l1
            


#non modificare
print(A_Ex2([15, 8, -4, 3, 12]))
    
