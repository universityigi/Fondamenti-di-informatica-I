def A_Ex4(file):
    filein = open(file, "r", encoding="UTF-8")
    filein.readline()
    riga = filein.readline().strip()
    diz={}
    vincenti=[]
    while len(riga)>0:
        l=riga.split(",")
        if l[0] not in diz:
            diz[l[0]]=[0,0]
        if l[1] not in diz:
            diz[l[1]]=[0,0]
        diz[l[0]][0]+=1
        diz[l[1]][0]+=1
        if int(l[2])>int(l[3]):
            diz[l[0]][1]+=1
        elif int(l[3])>int(l[2]):
            diz[l[1]][1]+=1
        elif l[3]==l[2]:
            diz[l[0]][1]+=1
            diz[l[1]][1]+=1
        riga=filein.readline().strip()
    for elem in diz:
        if int(diz[elem][0])==int(diz[elem][1]):
            vincenti.append(elem)
            vincenti.sort()
    return vincenti
    

#non modificare
print(A_Ex4("file1.csv"))
