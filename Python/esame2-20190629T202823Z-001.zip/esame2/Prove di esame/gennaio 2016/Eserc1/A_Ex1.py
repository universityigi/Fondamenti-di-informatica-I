def A_Ex1(l):
    somma=0
    div=0
    for elem in l:
        if int(elem)<=0:
            return -1
        else:
            for numero in str(elem):
                somma+=int(numero)
            if somma%7==0:
                div+=1
                somma=0
            else:
                somma=0
    return div

#non modificare
print(A_Ex1([43,72,68,16,3,189]))
