def A_Ex3(file):
    filein = open(file, "r", encoding="UTF-8")
    filein.readline()
    righe=filein.read()
    for riga in righe:
        print(riga)
    
    diz1={}
    diz2={}
    for riga in righe:
        l=riga.strip().split(",")
        print(l)
        if l[0] not in diz1:
            diz1[l[0]]=int(l[1])
        else:
            diz1[l[0]]+=int(l[1])
            
    for elem in diz1:
        if diz1[elem] not in diz2:
            diz2[diz1[elem]]=[]
            diz2[diz1[elem]].append(elem)
        else:
            diz2[diz1[elem]].append(elem)
            diz2[diz1[elem]].sort()
    return diz2

#non modificare
print(A_Ex3("file1.csv"))
