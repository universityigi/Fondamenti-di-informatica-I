def A_Ex2(s):
    car=""
    for n in range(len(s)):
        if s[n]==s[len(s)-n-1] and s[n] not in car:
            car+=s[n]
    return car


#non modificare
print(A_Ex2("prestare"))
