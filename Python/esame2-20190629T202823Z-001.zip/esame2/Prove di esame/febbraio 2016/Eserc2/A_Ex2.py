def A_Ex2(l):
    sommaprec=0
    sommasucc=0
    for n in range(len(l)):
        if n!=(len(l)-1):
            for elem in l[:n+1]:
                sommaprec+=elem
            for elem in l[n+1:]:
                sommasucc+=elem
            if sommaprec>sommasucc:
                return l[n]
            else:
                sommaprec=0
                sommasucc=0
        else:
            for elem in l[:n+1]:
                sommaprec+=1
            return l[n]
            
                
    return "NO"
                
            

#non modificare
print(A_Ex2([3,5,7,6,5]))
