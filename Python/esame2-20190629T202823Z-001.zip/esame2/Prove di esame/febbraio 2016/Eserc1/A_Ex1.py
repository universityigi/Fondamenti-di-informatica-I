def A_Ex1(s):
    s=s.split()
    diz={}
    rip=0
    maxchar=""
    for riga in s:
        if len(riga)>0 and (97<=ord(riga[0])<=122 or 65<=ord(riga[0])<=90):
            if riga[0].lower() not in diz:
                diz[riga[0].lower()]=1
            else:
                diz[riga[0].lower()]+=1
         
    for elem in diz:
        if diz[elem]>rip:
            rip=diz[elem]
            maxchar=elem
        elif diz[elem]==rip:
            if elem<maxchar:
                maxchar=elem
    return maxchar

#non modificare
print(A_Ex1('Lettera scritta\nsu righe\ndiverse\nlondra\nduemilasedici'))
