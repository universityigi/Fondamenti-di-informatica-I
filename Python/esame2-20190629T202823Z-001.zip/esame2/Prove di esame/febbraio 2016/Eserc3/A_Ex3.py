def A_Ex3(file):
    fin = open(file, "r", encoding="UTF-8")
    testo=fin.readline()
    testo=fin.readlines()
    numerorighe=0
    diz={}
    riga1=[]
    print(testo)
    for riga in testo:
        riga=riga.strip().split(",")
        for elem in riga:
            riga1.append(elem.strip())
        riga=riga1
        riga1=[]
        print(riga)
        if "" not in riga:

            if riga[0] not in diz:
                diz[riga[0]]=[]
                diz[riga[0]].append(int(riga[1]))
            else:
                posizione=len(diz[riga[0]])-1
                somma=int(diz[riga[0]][posizione])+int(riga[1])
                diz[riga[0]].append(int(somma))
            if diz[riga[0]][(len(diz[riga[0]])-1)]>1000:
                diz[riga[0]].append("BONUS")
                sottrazione=diz[riga[0]][(len(diz[riga[0]])-2)]-1000
                diz[riga[0]].append(sottrazione)
    fin.close()
    return diz


#non modificare
print(A_Ex3('file7.csv'))
