def A_Ex4(file):
    fin=open(file, "r", encoding="UTF-8")
    fin.readline()
    riga=fin.readline().strip()
    diz={}
    vincitore=[""]
    while len(riga)>0:
        riga=riga.split(",")
        if riga[0] not in diz:
            diz[riga[0]]=0
        if riga[1] not in diz:
            diz[riga[1]]=0
        if int(riga[2])>int(riga[3]):
            diz[riga[0]]+=1
        if int(riga[3])>int(riga[2]):
            diz[riga[1]]+=1
            
        maxvincite=0
        for elem in diz:
            if diz[elem]>maxvincite:
                maxvincite=diz[elem]
                vincitore.clear() 
                vincitore.append(elem)
            elif diz[elem]== maxvincite:
                if elem<vincitore[0]:
                    vincitore.clear()
                    vincitore.append(elem)
        riga=fin.readline().strip()
    if vincitore==[""]:
        vincitore.clear()
    return vincitore
    
#non modificare
print(A_Ex4('file1.csv'))
