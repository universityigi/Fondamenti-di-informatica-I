def A_Ex2(l):
    return None


#non modificare
print(A_Ex2([15, 8, -4, 3, 12]))
    
