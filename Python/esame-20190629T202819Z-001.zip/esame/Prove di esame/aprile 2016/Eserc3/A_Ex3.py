def A_Ex3(s):
    return None

#non modificare
print(A_Ex3('sasso'))
