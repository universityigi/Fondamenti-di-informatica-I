def A_Ex1(s):
    return None

#non modificare
print(A_Ex1('caso palese'))
