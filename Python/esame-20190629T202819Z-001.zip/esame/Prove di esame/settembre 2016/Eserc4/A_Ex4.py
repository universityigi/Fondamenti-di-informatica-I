def A_Ex4(file):
    return None

#non modificare
print(A_Ex4('file1.txt'))
    
