def A_Ex2(l):
    return None
    

#non modificare
print(A_Ex2([4, 7, 4, 9, 21]))
