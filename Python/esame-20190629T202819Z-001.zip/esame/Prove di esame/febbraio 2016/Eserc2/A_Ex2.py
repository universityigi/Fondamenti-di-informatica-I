def A_Ex2(l):
    return None

#non modificare
print(A_Ex2([3,5,7,6,5]))
