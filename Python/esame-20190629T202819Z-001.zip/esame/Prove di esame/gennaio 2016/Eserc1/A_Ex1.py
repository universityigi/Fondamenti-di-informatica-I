def A_Ex1(l):
    return None


#non modificare
print(A_Ex1([43,72,68,16,3,189]))
