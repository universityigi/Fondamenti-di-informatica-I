def A_Ex3(file):
    return None


#non modificare
print(A_Ex3("file1.csv"))
