def A_Ex2(s):
    return None


#non modificare
print(A_Ex2("prestare"))
