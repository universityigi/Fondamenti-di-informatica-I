#include "esercizio.h"
#include <stdlib.h>

ListItem* removeEquals(ListItem* list, int bad_value) {
  //TODO
  return NULL;
}

