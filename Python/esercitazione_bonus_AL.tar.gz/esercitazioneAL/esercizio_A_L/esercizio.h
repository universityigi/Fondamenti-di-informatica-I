#pragma once

struct ListItem_t {
  int value;
  struct ListItem_t* next;
};

typedef struct ListItem_t ListItem;


ListItem* removeEquals(ListItem* list, int bad_value);
