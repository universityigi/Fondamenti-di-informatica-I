#pragma once

struct ListItem_t {
  int value;
  struct ListItem_t* next;
};

typedef struct ListItem_t ListItem;


ListItem* removeBigger(ListItem* list, int bad_value);
