#include "esercizio.h"
#include <stdlib.h>

ListItem* removeBigger(ListItem* list, int bad_value) {
  //TODO
  return NULL;
}

