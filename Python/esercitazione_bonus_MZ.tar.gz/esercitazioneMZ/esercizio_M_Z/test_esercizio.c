#include <stdlib.h>
#include <stdio.h>
#include "esercizio.h"
#include "list_utils.h"

int main() {
  printf("***************************\n   Generating Random List\n***************************\n");
  int list_size = 20;
  int test_size = 10;
  int success = 0;
  
  ListItem* random_list = createRandomList(list_size);
  printList(random_list);

  for(int i=0; i<test_size; ++i) {
    printf("\n\n***************************\n   Test #%d \n***************************\n",i+1);

    //copy the original list
    ListItem* list = copyList(random_list);
    //pick a random number
    int bad_value = rand()%7 - 1;
    printf("* Remove values bigger than: %d\n", bad_value);

    //call the removeEquals method
    list = removeBigger(list, bad_value);
    if(checkResult(random_list, list, bad_value)){
      printf("\nSUCCESS!\n");
      success++;
    } else {
      printf("\nWRONG!\n");
    }

    freeList(list);  
  }

  printf("\n***************************");
  printf("\nFINAL SUCCESS RATE: %0.02f%%\n", (float)(success) * 100.0f / (float)(test_size));
  printf("***************************\n\n");
  
  
  freeList(random_list);
  
  return 0;
}
